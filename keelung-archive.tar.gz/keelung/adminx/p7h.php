<?php 

	if( !defined('K_COUCH_DIR') ) die(); // cannot be loaded directly
	
	function p7h( $o ){
		return clone( $o );
	}