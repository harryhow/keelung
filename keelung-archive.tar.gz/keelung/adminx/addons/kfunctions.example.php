<?php
if ( !defined('K_COUCH_DIR') ) die(); // cannot be loaded directly

//require_once( K_COUCH_DIR.'addons/cart/session.php' ); 
//require_once( K_COUCH_DIR.'addons/cart/cart.php' ); // automatically includes session
//require_once( K_COUCH_DIR.'addons/data-bound-form/data-bound-form.php' );
//require_once( K_COUCH_DIR.'addons/inline/inline.php' );

